﻿using System;

namespace GameEngine.Physics
{
    public class PhysicsObject
    {
        public Vector3 Position { get; set; }
        public Vector3 Velocity { get; set; }
        public Vector3 Acceleration { get; set; }
        public float Mass { get; set; }
        public bool IsGrounded { get; private set; }

        private const float Gravity = 9.81f;

        public PhysicsObject(float mass)
        {
            Mass = mass;
            Position = new Vector3(0, 0, 0);
            Velocity = new Vector3(0, 0, 0);
            Acceleration = new Vector3(0, 0, 0);
        }

        public void ApplyForce(Vector3 force)
        {
            // F = ma => a = F/m
            Vector3 accelerationChange = force / Mass;
            Acceleration = Acceleration + accelerationChange;
        }

        public void Update(float deltaTime)
        {
            // Apply gravity if not grounded
            if (!IsGrounded)
            {
                Vector3 newAcceleration = Acceleration;
                newAcceleration.Y -= Gravity * deltaTime;
                Acceleration = newAcceleration;
            }

            // Update velocity based on acceleration
            Vector3 newVelocity = Velocity;
            newVelocity += Acceleration * deltaTime;
            Velocity = newVelocity;

            // Update position based on velocity
            Vector3 newPosition = Position;
            newPosition += Velocity * deltaTime;
            Position = newPosition;

            // Check for ground collision (example with y=0 as the ground)
            if (Position.Y <= 0)
            {
                newPosition.Y = 0;
                Position = newPosition;
                IsGrounded = true;
                Velocity = new Vector3(Velocity.X, 0, Velocity.Z); // Stop downward velocity
            }
            else
            {
                IsGrounded = false;
            }

            // Reset acceleration
            Acceleration = new Vector3(0, 0, 0);
        }
    }

    public struct Vector3
    {
        public float X;
        public float Y;
        public float Z;

        public Vector3(float x, float y, float z)
        {
            X = x;
            Y = y;
            Z = z;
        }

        public static Vector3 operator +(Vector3 a, Vector3 b)
        {
            return new Vector3(a.X + b.X, a.Y + b.Y, a.Z + b.Z);
        }

        public static Vector3 operator -(Vector3 a, Vector3 b)
        {
            return new Vector3(a.X - b.X, a.Y - b.Y, a.Z - b.Z);
        }

        public static Vector3 operator *(Vector3 vec, float scalar)
        {
            return new Vector3(vec.X * scalar, vec.Y * scalar, vec.Z * scalar);
        }

        public static Vector3 operator /(Vector3 vec, float scalar)
        {
            return new Vector3(vec.X / scalar, vec.Y / scalar, vec.Z / scalar);
        }
    }
}
