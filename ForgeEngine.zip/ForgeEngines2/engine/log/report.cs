﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForgeEngines2.engine.log
{
    class report
    {
        public void ReportedShaderLogs()
        {
            float returnValueFromShader;
            float ShaderValueReport;
            ShaderValueReport = 0;
        }
    }
}
