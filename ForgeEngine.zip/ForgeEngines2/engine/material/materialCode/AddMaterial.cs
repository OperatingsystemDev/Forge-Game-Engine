﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForgeEngines2.engine.material.materialCode
{
    class AddMaterial
    {

        public string Name { get; set; }
        public string Description { get; set; }
        public string Type { get; set; }

        public void texture_render()
        {
            if (Name != null)
            {

            }
                
        }
        struct decal_texture()
        {
            float DecalTextureLoader; // loads the texture to a bianary to load the pixels from memory
            float DecalTextureCompiler;

        }
    }
}
