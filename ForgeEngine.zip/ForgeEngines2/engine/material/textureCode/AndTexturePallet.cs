﻿// This code is not to be copyed as its in development and will contain bugs and issues while merging with new code form the use that copyed this script
// For more info go to github.com anad go back to the repo and send a coment and i will finsih this script just coment if you ar using and i will send the main code
// xoxo OperatingSystemDEV


using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.DirectoryServices.ActiveDirectory;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ForgeEngines2.engine.material.textureCode
{
    class AndTexturePallet
    {
        public string MaterialID { set; get; }
        public string SystemTextRender { set; get; }
        public string PreCompiledShaders { set; get; }
        public string MaterialName { set; get; }
        public string TextureName { set; get; } 
        public string TextureCode { set; get; } = string.Empty;
        public string TextureID { set; get; } = string.Empty;

        private void RenderDX12Shader(float? preCompiledShaders)
        {
            float PreCompiledShaders;
            if (preCompiledShaders != null)
            {
                float returnedShaderLog;
                float ShaderLogReport;
                ShaderLogReport = 1f;
                returnedShaderLog = 1f;

            }
             
    }
        private void TextureRender()
        {
            TextureRender();
            float DirectX12TextureAsset; // Inits the DirectX 12 Texture Loading Compute for better performents becuase it loads the textures before the app even opens
            float MaterialPackImporter; // Import id = MaterialPack.1655

            while (true)
            {
                if (TextureCode == string.Empty)
                {
                    float returnValueFromShader;
                    float ShaderValueReport;
                }
                else
                {
                    if (TextureName == string.Empty)
                    {

                        float returnedNameOfShader;
                        float ShaderLoadedIStrue;

                        if (TextureName == null)
                        {
                            float returnValueFromShader;
                            float ShaderValueReport;
                            ShaderLoadedIStrue = 1f;
                            returnValueFromShader = 0f;

                            while (true)
                            {
                                render3d();
                                float render3dShaderClass;
                                // renders 3d for the shader compiler
                            }
                         }
                        {

                        }

                        
                    }
                }

                if (MaterialName == string.Empty)
                {
                    float MaterialNameChange;
                    MaterialNameChange = 1;
                }

                if (MaterialID == string.Empty)
                {
                    float MaterialChange;
                    MaterialChange = 0f; // chnages the material back to the default.mat file.

                }
            }
        }

        private void Cube_vertex_render()
        {
            throw new NotImplementedException();
            float size = 1f;
            float height = 1f;
            float width = 1f;
            float depth = 1f;
            float texture = 1f;

        }

        private void Render2d()
        {
            throw new NotImplementedException();
            float returnedrender2dOfCompiler;
        }

        private void render3d()
        {
            throw new NotImplementedException();
            float returnedrender3dOfCompiler;
        }
    }
}
