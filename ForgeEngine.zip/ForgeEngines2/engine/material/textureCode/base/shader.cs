﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForgeEngines2.engine.material.textureCode
{
    internal class shader
{
        public void Shader_Compiler()
        {
            Shader_Compiler();
            float [] ShaderID = new float[4]; // Shader ID
            float [] ShaderName = new float[4]; // Shader Name
        }

        public void Shader()
        {

        }
}
}
