﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForgeEngines2.engine.src.data
{
    internal class scriptingbackend
    {
        float backend;
        float backendcompiler;

        public void Backend()
        {
            if (backend == 0)
            {
                float syntaxcompiler;
                while (true)
                {
                    syntaxcompiler = 0;
                }
            }
        }


    }
}
