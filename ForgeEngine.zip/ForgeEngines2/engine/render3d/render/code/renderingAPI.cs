﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForgeEngines2.engine.render3d.render.code
{
    internal class renderingAPI
    {


        public renderingAPI(renderingAPI renderingAPI) {
            if (renderingAPI == null)
            {
                return;
            }
        }
    }
}
